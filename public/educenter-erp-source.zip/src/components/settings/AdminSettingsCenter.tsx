import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Shield,
  Layers,
  Building2,
  DollarSign,
  QrCode,
  Users,
  Clock,
  MessageSquare,
  Cloud,
  History,
  FileSpreadsheet,
  Printer,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Save,
  Check,
  X,
  Eye,
  EyeOff,
  Server,
  Database,
  Sparkles,
  Zap,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Percent,
  Plus,
  Trash2,
  Edit3
} from 'lucide-react';
import {
  systemSettingsManager,
  SystemSettingsConfig,
  SystemModuleKey,
  StudentDiscountRule,
  DEFAULT_SYSTEM_SETTINGS
} from '../../lib/system-settings';
import {
  exportToCsvExcel,
  exportToPrintablePdf,
  downloadFullSystemBackupFile,
  validateAndParseBackupFile,
  createFullSystemBackup
} from '../../lib/export-engine';

export interface AdminSettingsCenterProps {
  onNavigateToView?: (view: any) => void;
}

export default function AdminSettingsCenter({ onNavigateToView }: AdminSettingsCenterProps) {
  const [activeTab, setActiveTab] = useState<'modules' | 'discounts' | 'backup' | 'export' | 'branding'>('modules');
  const [settings, setSettings] = useState<SystemSettingsConfig>(() => systemSettingsManager.getSettings());
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Discount states
  const [isAddingDiscount, setIsAddingDiscount] = useState(false);
  const [newDiscTitle, setNewDiscTitle] = useState('');
  const [newDiscPercent, setNewDiscPercent] = useState(15);
  const [newDiscDesc, setNewDiscDesc] = useState('');

  // Backup states
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [lastBackupFile, setLastBackupFile] = useState<string | null>(null);
  const [restoreStatus, setRestoreStatus] = useState<{ success: boolean; message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Subscribe to changes
  useEffect(() => {
    const unsubscribe = systemSettingsManager.subscribe((updated) => {
      setSettings(updated);
    });
    return unsubscribe;
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleToggleModule = (modKey: SystemModuleKey) => {
    const currentVal = !!settings.enabledModules[modKey];
    const updated = systemSettingsManager.toggleModule(modKey, !currentVal);
    setSettings(updated);
    showToast(`تم ${!currentVal ? 'تفعيل' : 'إخفاء'} قسم [${getModuleTitle(modKey)}] بنجاح`);
  };

  const handleAddDiscountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDiscTitle.trim()) return;
    const updated = systemSettingsManager.addDiscountRule({
      title: newDiscTitle,
      percent: newDiscPercent,
      description: newDiscDesc || 'خصم طلابي معتمد',
      active: true
    });
    setSettings(updated);
    setIsAddingDiscount(false);
    setNewDiscTitle('');
    setNewDiscPercent(15);
    setNewDiscDesc('');
    showToast('تمت إضافة نسبة الخصم الجديدة بنجاح');
  };

  const handleDeleteDiscount = (id: string) => {
    const updated = systemSettingsManager.deleteDiscountRule(id);
    setSettings(updated);
    showToast('تم حذف نسبة الخصم بنجاح');
  };

  const handleToggleDiscount = (id: string, current: boolean) => {
    const updated = systemSettingsManager.updateDiscountRule(id, { active: !current });
    setSettings(updated);
    showToast(`تم ${!current ? 'تفعيل' : 'تعطيل'} الخصم بنجاح`);
  };

  const handleApplyPreset = (preset: 'FULL' | 'FINANCE_QR' | 'SIMPLE') => {
    let newModules: Record<SystemModuleKey, boolean>;

    if (preset === 'FULL') {
      newModules = {
        dashboard: true,
        student360: true,
        attendance: true,
        finance: true,
        analytics: true,
        teachers: true,
        payroll: true,
        automation: true,
        scheduler: true,
        backup: true,
        audit: true,
        roles: true,
        backend: true,
        database: true
      };
    } else if (preset === 'FINANCE_QR') {
      newModules = {
        dashboard: true,
        student360: true,
        attendance: true,
        finance: true,
        analytics: true,
        teachers: false,
        payroll: false,
        automation: true,
        scheduler: false,
        backup: true,
        audit: false,
        roles: false,
        backend: false,
        database: false
      };
    } else {
      // SIMPLE
      newModules = {
        dashboard: true,
        student360: true,
        attendance: true,
        finance: true,
        analytics: false,
        teachers: false,
        payroll: false,
        automation: false,
        scheduler: false,
        backup: false,
        audit: false,
        roles: false,
        backend: false,
        database: false
      };
    }

    const updated = systemSettingsManager.saveSettings({ enabledModules: newModules });
    setSettings(updated);
    showToast('تم تطبيق النموذج المختار بنجاح على القائمة الرئيسية');
  };

  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    systemSettingsManager.saveSettings(settings);
    setTimeout(() => {
      setIsSaving(false);
      showToast('تم حفظ إعدادات وهوية السنتر بنجاح');
    }, 400);
  };

  // 1-Click Instant Full Backup
  const handleInstantBackup = async () => {
    setIsBackingUp(true);
    try {
      const filename = await downloadFullSystemBackupFile({
        centerInfo: {
          name: settings.centerName,
          currency: settings.currency,
          phone: settings.centerPhone,
          defaultSplitPercent: settings.defaultTeacherSplit
        },
        enabledModules: settings.enabledModules
      });
      setLastBackupFile(filename);
      showToast(`تم تنزيل النسخة الاحتياطية الكاملة (${filename}) بنجاح!`);
    } catch (err: any) {
      showToast('حدث خطأ أثناء سحب النسخة الاحتياطية');
    } finally {
      setIsBackingUp(false);
    }
  };

  // Restore from file
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target?.result as string;
      const result = await validateAndParseBackupFile(content);
      if (result.isValid && result.payload) {
        if (result.payload.centerInfo) {
          systemSettingsManager.saveSettings({
            centerName: result.payload.centerInfo.name,
            currency: result.payload.centerInfo.currency,
            centerPhone: result.payload.centerInfo.phone,
            defaultTeacherSplit: result.payload.centerInfo.defaultSplitPercent,
            enabledModules: (result.payload.enabledModules as any) || settings.enabledModules
          });
        }
        setRestoreStatus({
          success: true,
          message: `تم استعادة النسخة الاحتياطية بنجاح (${result.payload.studentsCount} طالب، ${result.payload.treasuryTransactionsCount} معاملة مالية)`
        });
        showToast('تم استعادة بيانات النظام بالكامل بنجاح!');
      } else {
        setRestoreStatus({
          success: false,
          message: result.error || 'فشل استرجاع الملف'
        });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Sample data sets for instant Excel / PDF exports
  const handleExportStudents = (format: 'EXCEL' | 'PDF') => {
    const headers = ['كود الطالب', 'اسم الطالب', 'رقم الهاتف', 'المرحلة الدراسية', 'المبلغ المتأخر', 'حالة الحساب'];
    const rows = [
      ['ST-2026-0012', 'أحمد محمود رضوان', '01012345678', 'الصف الثالث الثانوي', '0 ج.م', 'منتظم'],
      ['ST-2026-0045', 'مريم طارق الشريف', '01198765432', 'الصف الثاني الثانوي', '60 ج.م', 'متأخر (حصة)'],
      ['ST-2026-0089', 'يوسف حسام الدين', '01234567891', 'الصف الثالث الثانوي', '0 ج.م', 'منتظم'],
      ['ST-2026-0104', 'نور الهدى إبراهيم', '01511223344', 'الصف الأول الثانوي', '150 ج.م', 'متأخر (شهر)']
    ];

    if (format === 'EXCEL') {
      exportToCsvExcel('كشف_الطلاب_والاشتراكات', headers, rows);
      showToast('تم تصدير كشف الطلاب بتنسيق Excel (UTF-8 BOM) بنجاح!');
    } else {
      exportToPrintablePdf({
        title: 'كشف قيد الطلاب والاشتراكات المالية',
        subtitle: 'بيان تفصيلي بأسماء الطلاب وحالات سداد الرسوم',
        centerName: settings.centerName,
        headers,
        rows,
        summaryCards: [
          { label: 'إجمالي الطلاب المقيدين', value: '4 طلاب', color: '#0284c7' },
          { label: 'إجمالي المبالغ المتأخرة', value: '210 ج.م', color: '#e11d48' },
          { label: 'نسبة الانتظام المالي', value: '75.0%', color: '#16a34a' }
        ]
      });
    }
  };

  const handleExportTreasury = (format: 'EXCEL' | 'PDF') => {
    const headers = ['رقم الإيصال', 'نوع الحركة', 'المبلغ', 'البيان والتفاصيل', 'التاريخ والوقت', 'المسؤول'];
    const rows = [
      ['TX-1001', 'إيداع نقدي', '350 ج.م', 'سداد اشتراك شهري فيزياء 3ث', '2026/10/31 10:15', 'أ. طارق الشافعي'],
      ['TX-1002', 'إيداع نقدي', '300 ج.م', 'سداد كيمياء عضوية', '2026/10/31 11:30', 'أ. طارق الشافعي'],
      ['TX-1003', 'صرف مصاريف', '450 ج.م', 'صيانة أجهزة وتصوير مذكرات', '2026/10/31 12:45', 'د. محمود عبد العزيز'],
      ['TX-1004', 'إيداع نقدي', '700 ج.م', 'سداد مجمع لمجموعتين', '2026/10/31 14:20', 'أ. طارق الشافعي']
    ];

    if (format === 'EXCEL') {
      exportToCsvExcel('تقرير_حركة_الخزنة_المركزية', headers, rows);
      showToast('تم تصدير حركة الخزنة بتنسيق Excel بنجاح!');
    } else {
      exportToPrintablePdf({
        title: 'تقرير حركة الخزنة المركزية وسندات القبض والصرف',
        subtitle: 'كشف مالي معتمد بالتدفقات النقدية الداخلة والخارجة',
        centerName: settings.centerName,
        headers,
        rows,
        summaryCards: [
          { label: 'إجمالي المقبوضات (Cash In)', value: '+1,350 ج.م', color: '#16a34a' },
          { label: 'إجمالي المصروفات (Cash Out)', value: '-450 ج.م', color: '#e11d48' },
          { label: 'صافي الرصيد النقدي', value: '900 ج.م', color: '#0284c7' }
        ]
      });
    }
  };

  const handleExportAttendance = (format: 'EXCEL' | 'PDF') => {
    const headers = ['كود الطالب', 'اسم الطالب', 'المجموعة', 'وقت المسح', 'توثيق HMAC', 'طريقة الحساب'];
    const rows = [
      ['ST-2026-0012', 'أحمد محمود رضوان', 'فيزياء متقدمة', '02:02:15 م', 'موثق مشفر ✓', 'اشتراك شهري'],
      ['ST-2026-0045', 'مريم طارق الشريف', 'كيمياء عضوية', '02:05:40 م', 'موثق مشفر ✓', 'بالحصة (+60 ج.م)'],
      ['ST-2026-0089', 'يوسف حسام الدين', 'فيزياء متقدمة', '02:10:12 م', 'موثق مشفر ✓', 'اشتراك شهري']
    ];

    if (format === 'EXCEL') {
      exportToCsvExcel('سجل_حضور_الطلاب_QR', headers, rows);
      showToast('تم تصدير سجل الحضور المشفر بتنسيق Excel بنجاح!');
    } else {
      exportToPrintablePdf({
        title: 'سجل الحضور الذكي بالـ QR والتوقيع الرقمي',
        subtitle: 'بيان الحضور اللحظي المحمي بتوقيع HMAC-SHA256 المشفر',
        centerName: settings.centerName,
        headers,
        rows,
        summaryCards: [
          { label: 'عدد الحاضرين اليوم', value: '3 طلاب', color: '#16a34a' },
          { label: 'التوقيعات المشفرة السليمة', value: '100%', color: '#0284c7' },
          { label: 'رسوم الحصص المضافة', value: '+60 ج.م', color: '#d97706' }
        ]
      });
    }
  };

  const getModuleTitle = (key: SystemModuleKey): string => {
    const titles: Record<SystemModuleKey, string> = {
      dashboard: 'المؤشرات والعمليات (Live KPIs)',
      student360: 'ملف الطالب 360 (Student 360)',
      attendance: 'حضور الـ QR والـ HMAC',
      finance: 'ماليات الطالب والإيصالات',
      analytics: 'تحليلات الخزنة والأرباح',
      teachers: 'بوابة المدرسين ونسب الأرباح',
      payroll: 'مسير الرواتب والموظفين',
      automation: 'أوتوميشن ورسائل الواتساب',
      scheduler: 'مجدول المهام الدورية',
      backup: 'الأرشفة والنسخ الاحتياطي السحابي',
      audit: 'سجل التدقيق والرقابة (Audit)',
      roles: 'إدارة الأدوار والصلاحيات (RBAC)',
      backend: 'سيرفر FastAPI ومحددات الأمان',
      database: 'تريجرز وقاعدة بيانات PostgreSQL'
    };
    return titles[key] || key;
  };

  const getModuleCategory = (key: SystemModuleKey): 'CORE' | 'FINANCE' | 'AUTOMATION' | 'TECH' => {
    if (['dashboard', 'student360', 'attendance'].includes(key)) return 'CORE';
    if (['finance', 'analytics', 'teachers', 'payroll'].includes(key)) return 'FINANCE';
    if (['automation', 'scheduler', 'backup', 'audit'].includes(key)) return 'AUTOMATION';
    return 'TECH';
  };

  return (
    <div className="space-y-6 font-['Cairo',sans-serif]" dir="rtl">
      
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-800/80 px-3.5 py-1 rounded-full">
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>لوحة تحكم المدير المرنة (Dynamic Admin Control Panel)</span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              الإعدادات الشاملة والتحكم بالأقسام والنسخ الاحتياطي
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              تحكم كامل في إظهار أو إخفاء أي قسم في المنظومة، سحب نسخة احتياطية كاملة لجهازك بضغطة زر واحدة، تصدير التقارير إلى Excel و PDF بتنسيق عربي مضبوط، وإدارة هوية السنتر.
            </p>
          </div>

          {/* 1-Click Instant Full Backup Button */}
          <button
            onClick={handleInstantBackup}
            disabled={isBackingUp}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 text-xs font-black transition-all shadow-xl shadow-emerald-500/20 flex items-center gap-2.5 cursor-pointer disabled:opacity-50"
          >
            {isBackingUp ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري سحب النسخة وحفظها...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>سحب نسخة احتياطية كاملة لجهازي الآن (1-Click)</span>
              </>
            )}
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
          <button
            onClick={() => setActiveTab('modules')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'modules'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>التحكم بالأقسام والظهور (Module Manager)</span>
          </button>

          <button
            onClick={() => setActiveTab('discounts')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'discounts'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            <Percent className="w-4 h-4 text-amber-400" />
            <span>نسب الخصومات والعروض للطلاب</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'backup'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            <Cloud className="w-4 h-4" />
            <span>النسخ الاحتياطي والاسترجاع (Instant Backup)</span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'export'
                ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>مركز التصدير المتقن (Excel & PDF)</span>
          </button>

          <button
            onClick={() => setActiveTab('branding')}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'branding'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>هوية السنتر والقواعد المالية (Center Brand)</span>
          </button>
        </div>

        {toastMessage && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}
      </div>

      {/* Tab 1: Module Visibility & Permissions Manager */}
      {activeTab === 'modules' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-400" />
                  <span>تخصيص القائمة الرئيسية والأقسام المفعلة</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  يمكنك إظهار أو إخفاء أي قسم بنقرة واحدة. التغييرات تنعكس فورياً على الشريط العلوي لكافة المستخدمين.
                </p>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-slate-500">نماذج سريعة:</span>
                <button
                  onClick={() => handleApplyPreset('FULL')}
                  className="px-3 py-1.5 rounded-xl bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-800 text-indigo-300 text-xs font-bold transition-all cursor-pointer"
                >
                  الوضع الكامل (Full ERP)
                </button>
                <button
                  onClick={() => handleApplyPreset('FINANCE_QR')}
                  className="px-3 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-xs font-bold transition-all cursor-pointer"
                >
                  الماليات والحضور فقط
                </button>
                <button
                  onClick={() => handleApplyPreset('SIMPLE')}
                  className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold transition-all cursor-pointer"
                >
                  الوضع المبسط (Simple)
                </button>
              </div>
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(Object.keys(settings.enabledModules) as SystemModuleKey[]).map((modKey) => {
                const isEnabled = !!settings.enabledModules[modKey];
                const category = getModuleCategory(modKey);
                return (
                  <div
                    key={modKey}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      isEnabled
                        ? 'bg-slate-950/80 border-indigo-500/40 shadow-md'
                        : 'bg-slate-950/30 border-slate-800/80 opacity-60'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold bg-slate-900 text-slate-400 border border-slate-800">
                          {category}
                        </span>
                        
                        {/* Toggle Switch */}
                        <div
                          onClick={() => handleToggleModule(modKey)}
                          className={`w-11 h-6 rounded-full transition-colors p-1 cursor-pointer flex items-center ${
                            isEnabled ? 'bg-indigo-600 justify-end' : 'bg-slate-800 justify-start'
                          }`}
                        >
                          <div className="w-4 h-4 rounded-full bg-white shadow-md transform transition-transform" />
                        </div>
                      </div>

                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        {isEnabled ? (
                          <Eye className="w-3.5 h-3.5 text-indigo-400" />
                        ) : (
                          <EyeOff className="w-3.5 h-3.5 text-slate-600" />
                        )}
                        <span>{getModuleTitle(modKey)}</span>
                      </h4>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {modKey === 'attendance' && 'قارئ كاميرا الـ QR المباشر مع فحص HMAC وتأكيد الحضور المالي.'}
                        {modKey === 'student360' && 'ملف الطالب الشامل وسجل الدرجات والاشتراكات الشهرية.'}
                        {modKey === 'finance' && 'إيصالات السداد وحسابات الطلاب النقدية.'}
                        {modKey === 'analytics' && 'مخططات تدفقات الخزنة النقدية والأرباح الصافية.'}
                        {modKey === 'teachers' && 'محافظ المدرسين ونسب الحصص (70/30).'}
                        {modKey === 'payroll' && 'مسير رواتب الموظفين وحساب ساعات العمل والتأخير.'}
                        {modKey === 'automation' && 'محرر قوالب رسائل الواتساب بدون أكواد.'}
                        {modKey === 'scheduler' && 'جدولة المهام والإنذارات التلقائية عبر الواتساب.'}
                        {modKey === 'backup' && 'سحب نسخ احتياطية واسترجاعها سحابياً.'}
                        {modKey === 'audit' && 'سجل التدقيق لكشف أي تعديل أو حذف في الخزنة والطلاب.'}
                        {modKey === 'roles' && 'إدارة صلاحيات الموظفين والمستخدمين (RBAC).'}
                        {modKey === 'backend' && 'وثائق ومواصفات خادم FastAPI ونماذج Pydantic.'}
                        {modKey === 'database' && 'تريجرز PostgreSQL المؤتمتة لحفظ سلامة الحسابات.'}
                        {modKey === 'dashboard' && 'شاشة المؤشرات اللحظية والإحصائيات التراكمية اليومية.'}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className={isEnabled ? 'text-indigo-300 font-bold' : 'text-slate-500'}>
                        {isEnabled ? 'ظاهر في القائمة' : 'مخفي حالياً'}
                      </span>
                      {isEnabled && onNavigateToView && (
                        <button
                          onClick={() => onNavigateToView(modKey)}
                          className="text-slate-400 hover:text-white flex items-center gap-1 transition-colors text-[10px]"
                        >
                          <span>فتح القسم</span>
                          <ArrowRight className="w-3 h-3 rtl:rotate-180" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Student Discounts & Offers */}
      {activeTab === 'discounts' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Percent className="w-4 h-4 text-amber-400" />
                  <span>تحديد ونسب الخصومات والعروض للطلاب والمصروفات</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  صلاحية حصرية لمدير السنتر لإدارة سياسات الخصم (الأشقاء، المتفوقين، الأيتام والحالات الإنسانية) وتطبيقها تلقائياً على فواتير الطلاب.
                </p>
              </div>

              <button
                onClick={() => setIsAddingDiscount(true)}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-lg shadow-amber-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ إضافة نسبة خصم جديدة</span>
              </button>
            </div>

            {/* Discounts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {settings.studentDiscounts.map((disc) => (
                <div
                  key={disc.id}
                  className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                    disc.active
                      ? 'bg-slate-950/80 border-amber-500/40 shadow-md'
                      : 'bg-slate-950/40 border-slate-800/80 opacity-60'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 font-mono font-bold text-sm border border-amber-500/30">
                        {disc.percent}% خصم معتمد
                      </span>

                      {/* Toggle Switch */}
                      <div
                        onClick={() => handleToggleDiscount(disc.id, disc.active)}
                        className={`w-11 h-6 rounded-full transition-colors p-1 cursor-pointer flex items-center ${
                          disc.active ? 'bg-amber-500 justify-end' : 'bg-slate-800 justify-start'
                        }`}
                        title={disc.active ? 'تعطيل هذا الخصم' : 'تفعيل هذا الخصم'}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow-md transform transition-transform" />
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-white">{disc.title}</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">{disc.description}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className={disc.active ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                      {disc.active ? 'مفعل ويطبق على اشتراكات الطلاب' : 'معطل حالياً'}
                    </span>

                    <button
                      onClick={() => handleDeleteDiscount(disc.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="حذف نسبة الخصم"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Add Discount Modal */}
      {isAddingDiscount && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleAddDiscountSubmit} className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Percent className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">إضافة نسبة خصم أو عرض جديد</h3>
              </div>
              <button type="button" onClick={() => setIsAddingDiscount(false)} className="text-slate-500 hover:text-slate-300">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">مسمى الخصم / العرض:</label>
                <input
                  type="text"
                  placeholder="مثال: خصم أبناء المعلمين 30%"
                  value={newDiscTitle}
                  onChange={(e) => setNewDiscTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:ring-1 focus:ring-amber-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">نسبة الخصم (%):</label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={newDiscPercent}
                    onChange={(e) => setNewDiscPercent(Number(e.target.value) || 0)}
                    className="w-24 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-center focus:ring-1 focus:ring-amber-500 text-sm font-bold"
                    required
                  />
                  <span className="text-slate-400 font-mono">% من إجمالي المصروفات</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold block">شروط وتفاصيل الاستحقاق:</label>
                <textarea
                  rows={3}
                  placeholder="وضح شروط تطبيق الخصم وإجراءات الاعتماد..."
                  value={newDiscDesc}
                  onChange={(e) => setNewDiscDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-white leading-relaxed focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="submit"
                className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow cursor-pointer"
              >
                تأكيد واعتماد نسبة الخصم
              </button>
              <button
                type="button"
                onClick={() => setIsAddingDiscount(false)}
                className="px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl text-xs cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 2: Instant 1-Click Backup & Restore */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* 1-Click Backup Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Download className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">سحب نسخة احتياطية فورية (Instant Backup)</h3>
                  <p className="text-xs text-slate-400">تنزيل ملف كامل وشامل لقاعدة البيانات والسيستم لجهازك مباشرة</p>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs space-y-2.5">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>محتويات النسخة الاحتياطية المشفرة:</span>
                </div>
                <ul className="text-slate-300 space-y-1.5 list-disc list-inside text-[11px] leading-relaxed">
                  <li>بيانات وملفات جميع الطلاب وحالات سداد الرسوم.</li>
                  <li>حركة الخزنة المركزية وسندات القبض والصرف ورصيد السيولة.</li>
                  <li>سجلات حضور الـ QR المشفرة وتوقيعات الـ HMAC.</li>
                  <li>كشوف رواتب ومحافظ المدرسين ونسب الأرباح.</li>
                  <li>قواعد ومحرر رسائل الواتساب التلقائية.</li>
                  <li>رمز التحقق الرقمي المشفر (SHA-256 Checksum) لضمان عدم تلف البيانات.</li>
                </ul>
              </div>

              <button
                onClick={handleInstantBackup}
                disabled={isBackingUp}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isBackingUp ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري سحب وتشفير النسخة...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>تنزيل النسخة الاحتياطية الآن على جهازي (.json)</span>
                  </>
                )}
              </button>

              {lastBackupFile && (
                <div className="text-[11px] text-emerald-300 bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/60 flex items-center justify-between font-mono">
                  <span>تم التنزيل: {lastBackupFile}</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                </div>
              )}
            </div>

            {/* Restore from File Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">استعادة نسخة سابقة (Restore Backup)</h3>
                  <p className="text-xs text-slate-400">رفع ملف نسخة احتياطية واسترجاع البيانات بضغطة زر</p>
                </div>
              </div>

              <div className="border-2 border-dashed border-slate-700 hover:border-cyan-500/60 rounded-2xl p-6 text-center space-y-3 transition-colors bg-slate-950/50">
                <Cloud className="w-10 h-10 text-slate-500 mx-auto" />
                <div>
                  <label
                    htmlFor="backup-file-upload"
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs inline-flex items-center gap-2 cursor-pointer shadow transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>اختر ملف النسخة الاحتياطية من جهازك</span>
                  </label>
                  <input
                    id="backup-file-upload"
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleRestoreFile}
                    className="hidden"
                  />
                </div>
                <p className="text-[11px] text-slate-500">يقبل ملفات النسخ الاحتياطية الرسمية بنسق (.json)</p>
              </div>

              {restoreStatus && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
                    restoreStatus.success
                      ? 'bg-emerald-950/40 border-emerald-800 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-800 text-rose-200'
                  }`}
                >
                  {restoreStatus.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <span className="leading-relaxed">{restoreStatus.message}</span>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* Tab 3: Universal Excel & PDF Exporter */}
      {activeTab === 'export' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                <span>مركز تصدير التقارير المتقنة (Excel & Vector PDF)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                تصدير فوري بضغطة زر مع ضمان الدقة الكاملة للحروف والكلمات العربية بدون أي تشويش (دعم UTF-8 BOM للإكسيل وتصميم متقن للـ PDF).
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Export Card 1: Students */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                    <Users className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold text-white">كشف قيد الطلاب والاشتراكات</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    يشمل أرقام الهواتف، المراحل الدراسية، المبالغ المستحقة، وحالة الحساب المالي.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleExportStudents('EXCEL')}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>تصدير Excel</span>
                  </button>
                  <button
                    onClick={() => handleExportStudents('PDF')}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all border border-slate-700 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة / PDF</span>
                  </button>
                </div>
              </div>

              {/* Export Card 2: Treasury */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                    <DollarSign className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold text-white">حركة الخزنة المركزية وسندات القبض</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    تقرير مالي بالتدفقات النقدية الداخلة والخارجة، أرقام الإيصالات، واسم المحاسب.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleExportTreasury('EXCEL')}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>تصدير Excel</span>
                  </button>
                  <button
                    onClick={() => handleExportTreasury('PDF')}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all border border-slate-700 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة / PDF</span>
                  </button>
                </div>
              </div>

              {/* Export Card 3: Attendance */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold text-white">سجل الحضور الذكي بالـ QR</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    توثيق أوقات مسح الكروت، مطابقة بصمة HMAC، والخصم المالي لحصص اليوم.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleExportAttendance('EXCEL')}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>تصدير Excel</span>
                  </button>
                  <button
                    onClick={() => handleExportAttendance('PDF')}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all border border-slate-700 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة / PDF</span>
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Center Brand & Policies */}
      {activeTab === 'branding' && (
        <form onSubmit={handleSaveBranding} className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-purple-400" />
                <span>هوية السنتر والقواعد التشغيلية والمالية</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                تظهر هذه البيانات في ترويسة الإيصالات، كشوفات الطباعة، ورسائل الواتساب.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
              
              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">اسم السنتر التجاري:</label>
                <input
                  type="text"
                  value={settings.centerName}
                  onChange={(e) => setSettings({ ...settings, centerName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:ring-1 focus:ring-purple-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">رقم هاتف السنتر للواتساب:</label>
                <input
                  type="tel"
                  value={settings.centerPhone}
                  onChange={(e) => setSettings({ ...settings, centerPhone: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono focus:ring-1 focus:ring-purple-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">رمز العملة الافتراضية:</label>
                <input
                  type="text"
                  value={settings.currency}
                  onChange={(e) => setSettings({ ...settings, currency: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:ring-1 focus:ring-purple-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">نسبة المعلم الافتراضية (%):</label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="50"
                    max="90"
                    value={settings.defaultTeacherSplit}
                    onChange={(e) => setSettings({ ...settings, defaultTeacherSplit: Number(e.target.value) })}
                    className="flex-1"
                  />
                  <span className="font-mono font-bold text-purple-300 text-sm">
                    {settings.defaultTeacherSplit}% للمدرس
                  </span>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">فترة السماح قبل تسجيل الغياب (دقيقة):</label>
                <input
                  type="number"
                  min="5"
                  max="45"
                  value={settings.gracePeriodMinutes}
                  onChange={(e) => setSettings({ ...settings, gracePeriodMinutes: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono focus:ring-1 focus:ring-purple-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold block">عبارة تذييل الإيصالات المالية:</label>
                <input
                  type="text"
                  value={settings.receiptFooterNote}
                  onChange={(e) => setSettings({ ...settings, receiptFooterNote: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:ring-1 focus:ring-purple-500"
                />
              </div>

            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                * يتم تحديث الترويسة في كافة شاشات ومستندات المنظومة تلقائياً.
              </span>
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-all shadow-lg shadow-purple-600/20 flex items-center gap-2 cursor-pointer"
              >
                {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </div>
        </form>
      )}

    </div>
  );
}
