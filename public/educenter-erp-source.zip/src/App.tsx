import React, { useState, useEffect } from 'react';
import {
  Folder,
  FileCode,
  Shield,
  Zap,
  Database,
  LayoutGrid,
  CheckCircle2,
  Lock,
  QrCode,
  ArrowRight,
  Terminal,
  Copy,
  Check,
  Cpu,
  Sparkles,
  FileText,
  Building2,
  DollarSign,
  Share2,
  Clock,
  BookOpen,
  Play,
  RotateCcw,
  CheckCircle,
  Code,
  Key,
  Send,
  Eye,
  Server,
  LogOut,
  UserCheck,
  Users,
  Bell,
  Receipt,
  LineChart,
  BarChart3,
  ShieldCheck,
  UserCircle,
  Cloud,
  Calendar,
  History,
  Sliders,
  Download,
  FileSpreadsheet,
  Printer,
  MessageSquare
} from 'lucide-react';

import LoginPage from './components/auth/LoginPage';
import TeacherDashboard from './components/dashboard/TeacherDashboard';
import AttendanceScanner from './components/attendance/AttendanceScanner';
import StudentFinancials from './components/finance/StudentFinancials';
import NotificationCenter from './components/notifications/NotificationCenter';
import ExpenseManagement from './components/finance/ExpenseManagement';
import TreasuryAnalytics from './components/finance/TreasuryAnalytics';
import RoleManagement from './components/roles/RoleManagement';
import Student360View from './components/students/Student360View';
import PayrollManagement from './components/payroll/PayrollManagement';
import DatabaseBackupManager from './components/backup/DatabaseBackupManager';
import DashboardWidgets from './components/dashboard/DashboardWidgets';
import TaskSchedulerDashboard from './components/scheduler/TaskSchedulerDashboard';
import AuditLogViewer from './components/audit/AuditLogViewer';
import AdminSettingsCenter from './components/settings/AdminSettingsCenter';
import VisualAutomationBuilder from './components/scheduler/VisualAutomationBuilder';
import WhatsAppCenter from './components/notifications/WhatsAppCenter';
import { authStorage, UserSession } from './lib/auth-storage';
import { systemSettingsManager, SystemSettingsConfig } from './lib/system-settings';
import { downloadFullSystemBackupFile } from './lib/export-engine';

export default function App() {
  const [activeView, setActiveView] = useState<
    'settings' | 'whatsapp' | 'automation' | 'student360' | 'backup' | 'scheduler' | 'audit' | 'analytics' | 'payroll' | 'roles' | 'expenses' | 'notifications' | 'finance' | 'attendance' | 'teachers' | 'login' | 'dashboard' | 'backend' | 'database'
  >('dashboard');
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [systemSettings, setSystemSettings] = useState<SystemSettingsConfig>(() => systemSettingsManager.getSettings());
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupSuccess, setBackupSuccess] = useState<string | null>(null);

  // Listen to dynamic system settings changes across all tabs
  useEffect(() => {
    return systemSettingsManager.subscribe((updated) => {
      setSystemSettings(updated);
    });
  }, []);

  // Check stored session on mount
  useEffect(() => {
    const session = authStorage.getUser();
    if (session) {
      setCurrentUser(session);
    }
  }, []);

  const handleQuickBackup = async () => {
    try {
      setIsBackingUp(true);
      const filename = await downloadFullSystemBackupFile();
      setBackupSuccess(filename);
      setTimeout(() => setBackupSuccess(null), 4000);
    } catch (err) {
      console.error('Backup error:', err);
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleLoginSuccess = (user: UserSession) => {
    setCurrentUser(user);
    setActiveView('dashboard');
  };

  const handleLogout = () => {
    authStorage.clearSession();
    setCurrentUser(null);
    setActiveView('login');
  };

  // Determine current primary hub for high-level active highlight
  const isStudentsHub = activeView === 'student360' || activeView === 'attendance';
  const isFinanceHub = activeView === 'finance' || activeView === 'analytics' || activeView === 'expenses' || activeView === 'payroll' || activeView === 'teachers';
  const isWhatsAppHub = activeView === 'whatsapp' || activeView === 'automation' || activeView === 'scheduler';
  const isAdminHub = activeView === 'settings' || activeView === 'backup' || activeView === 'roles' || activeView === 'audit';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Cairo',sans-serif]">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/95 backdrop-blur-md sticky top-0 z-50 px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0">
              <Building2 className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white">EduCenter Smart ERP</h1>
                <span className="text-[11px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
                  لوحة الإدارة الذكية المبسطة
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                تحكم كامل بدون تعقيد • مراجعة رسائل الواتساب قبل الإرسال • إدارة نسب الخصومات • نسخ احتياطي وتصدير فوري
              </p>
            </div>
          </div>

          {/* Header Quick Actions: Instant 1-Click Backup & Profile */}
          <div className="flex items-center gap-2.5">
            {/* Instant Backup 1-Click Button */}
            <button
              onClick={handleQuickBackup}
              disabled={isBackingUp}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border border-emerald-500/40 flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/20 disabled:opacity-50"
              title="سحب نسخة احتياطية فورية شاملة لكل بيانات السنتر وحفظها على جهازك الشخصي"
            >
              {isBackingUp ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>جاري السحب...</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>نسخة احتياطية فورية (1-Click)</span>
                </>
              )}
            </button>

            {/* User Session Quick Profile */}
            {currentUser ? (
              <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 px-3 py-1.5 rounded-xl text-xs">
                <div className="w-6 h-6 rounded-lg bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">
                  {currentUser.fullName.charAt(0)}
                </div>
                <div>
                  <span className="text-white font-bold block leading-none">{currentUser.fullName}</span>
                  <span className="text-[10px] text-emerald-400 font-mono leading-none">{currentUser.roles[0]}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="mr-2 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                  title="تسجيل الخروج"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setActiveView('login')}
                className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border border-slate-700 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                <span>تسجيل الدخول</span>
              </button>
            )}
          </div>
        </div>

        {/* Streamlined Primary Navigation (5 Main Intuitive Hubs) */}
        <div className="max-w-7xl mx-auto mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none text-xs">
          <div className="flex items-center gap-2">
            {/* Hub 1: Dashboard */}
            {systemSettings.enabledModules.dashboard !== false && (
              <button
                onClick={() => setActiveView('dashboard')}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  activeView === 'dashboard'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
                <span>الرئيسية والمؤشرات</span>
              </button>
            )}

            {/* Hub 2: Students & Attendance */}
            {(systemSettings.enabledModules.student360 !== false || systemSettings.enabledModules.attendance !== false) && (
              <button
                onClick={() => setActiveView('student360')}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isStudentsHub
                    ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-600/20'
                    : 'text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>الطلاب والحضور</span>
              </button>
            )}

            {/* Hub 3: Finance & Treasury */}
            {(systemSettings.enabledModules.finance !== false || systemSettings.enabledModules.analytics !== false) && (
              <button
                onClick={() => setActiveView('finance')}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isFinanceHub
                    ? 'bg-teal-600 text-white font-bold shadow-md shadow-teal-600/20'
                    : 'text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800'
                }`}
              >
                <DollarSign className="w-4 h-4" />
                <span>الخزنة والماليات</span>
              </button>
            )}

            {/* Hub 4: WhatsApp Messages & Manual Approval */}
            {systemSettings.enabledModules.automation !== false && (
              <button
                onClick={() => setActiveView('whatsapp')}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                  isWhatsAppHub
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                    : 'text-emerald-300 hover:text-white bg-emerald-950/40 border border-emerald-900/40 hover:bg-emerald-900/30'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>رسائل الواتساب والاعتماد</span>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  طابور يدوي
                </span>
              </button>
            )}

            {/* Hub 5: Super Admin Control & Discounts */}
            <button
              onClick={() => setActiveView('settings')}
              className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                isAdminHub
                  ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/20'
                  : 'text-indigo-300 hover:text-white bg-indigo-950/40 border border-indigo-900/40 hover:bg-indigo-900/30'
              }`}
            >
              <Sliders className="w-4 h-4 text-indigo-400" />
              <span>تحكم المدير العام والخصومات</span>
            </button>
          </div>

          {/* Quick specs / developer options if enabled in settings */}
          {(systemSettings.enabledModules.backend === true || systemSettings.enabledModules.database === true) && (
            <div className="flex items-center gap-1.5 shrink-0">
              {systemSettings.enabledModules.backend === true && (
                <button
                  onClick={() => setActiveView('backend')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                    activeView === 'backend' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  FastAPI
                </button>
              )}
              {systemSettings.enabledModules.database === true && (
                <button
                  onClick={() => setActiveView('database')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                    activeView === 'database' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Triggers
                </button>
              )}
            </div>
          )}
        </div>

        {/* Secondary Contextual Sub-Nav Bar (Clean & Focused on Active Hub) */}
        {isStudentsHub && (
          <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-800/50 flex items-center gap-2 text-xs">
            <span className="text-[11px] text-slate-500 font-semibold ml-1">أقسام الطلاب:</span>
            <button
              onClick={() => setActiveView('student360')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
                activeView === 'student360'
                  ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserCircle className="w-3.5 h-3.5" />
              <span>ملف الطالب الشامل 360</span>
            </button>
            <button
              onClick={() => setActiveView('attendance')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
                activeView === 'attendance'
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>ماسح الحضور بالـ QR</span>
            </button>
          </div>
        )}

        {isFinanceHub && (
          <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-800/50 flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
            <span className="text-[11px] text-slate-500 font-semibold ml-1">العمليات المالية:</span>
            <button
              onClick={() => setActiveView('finance')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'finance'
                  ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>إيصالات وحسابات الطلاب</span>
            </button>
            <button
              onClick={() => setActiveView('analytics')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'analytics'
                  ? 'bg-teal-600/30 text-teal-300 border border-teal-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>تحليلات الخزنة والأرباح</span>
            </button>
            <button
              onClick={() => setActiveView('expenses')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'expenses'
                  ? 'bg-rose-600/30 text-rose-300 border border-rose-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>المصروفات اليومية</span>
            </button>
            <button
              onClick={() => setActiveView('payroll')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'payroll'
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>رواتب الموظفين والمدرسين</span>
            </button>
            <button
              onClick={() => setActiveView('teachers')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'teachers'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>نسب المدرسين وحصصهم</span>
            </button>
          </div>
        )}

        {isAdminHub && (
          <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-800/50 flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
            <span className="text-[11px] text-slate-500 font-semibold ml-1">إعدادات الإدارة:</span>
            <button
              onClick={() => setActiveView('settings')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'settings'
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>نسب الخصومات وتخصيص الأقسام والسياسات</span>
            </button>
            <button
              onClick={() => setActiveView('backup')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'backup'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>إدارة الأرشيف السحابي الكامل</span>
            </button>
            <button
              onClick={() => setActiveView('audit')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'audit'
                  ? 'bg-amber-600/30 text-amber-300 border border-amber-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>سجل التدقيق والرقابة (Audit)</span>
            </button>
            <button
              onClick={() => setActiveView('roles')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeView === 'roles'
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>صلاحيات الموظفين (RBAC)</span>
            </button>
          </div>
        )}
      </header>

      {/* Backup Success Toast Banner */}
      {backupSuccess && (
        <div className="bg-emerald-500/15 border-b border-emerald-500/30 px-6 py-2.5 text-xs text-emerald-300 animate-in fade-in duration-300">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                تم سحب النسخة الاحتياطية بنجاح وحفظها كملف مشفر على جهازك: <strong className="font-mono text-white">{backupSuccess}</strong>
              </span>
            </div>
            <button
              onClick={() => setBackupSuccess(null)}
              className="text-emerald-400 hover:text-emerald-200 text-xs cursor-pointer font-bold"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* Main Body */}
      <main className="max-w-7xl mx-auto w-full p-6 flex-1 flex flex-col">

        {/* View: Dynamic Admin Control Panel & Universal Export/Backup Center */}
        {activeView === 'settings' && (
          <AdminSettingsCenter onNavigateToView={(view: any) => setActiveView(view)} />
        )}

        {/* View: WhatsApp Manual Approval Queue & Visual No-Code Automation Builder */}
        {(activeView === 'whatsapp' || activeView === 'automation') && (
          <WhatsAppCenter />
        )}

        {/* View 1: Database Backup & Cloud Storage Archival Manager (Requested Feature) */}
        {activeView === 'backup' && (
          <DatabaseBackupManager />
        )}

        {/* View: Task Scheduler & WhatsApp Automated Notifications */}
        {activeView === 'scheduler' && (
          <TaskSchedulerDashboard />
        )}

        {/* View: Database Audit Logs & Transparency Triggers (Requested Feature) */}
        {activeView === 'audit' && (
          <AuditLogViewer />
        )}

        {/* View 2: Student 360 Full Archive Profile */}
        {activeView === 'student360' && (
          <Student360View />
        )}

        {/* View 3: Attendance Scanner Component */}
        {activeView === 'attendance' && (
          <AttendanceScanner />
        )}

        {/* View 4: Student Financials Component */}
        {activeView === 'finance' && (
          <StudentFinancials />
        )}

        {/* View 5: Treasury Analytics Component */}
        {activeView === 'analytics' && (
          <TreasuryAnalytics />
        )}

        {/* View 6: Teacher Dashboard & Revenue Splits */}
        {activeView === 'teachers' && (
          <TeacherDashboard />
        )}

        {/* View 7: Staff Attendance & Payroll Management */}
        {activeView === 'payroll' && (
          <PayrollManagement />
        )}

        {/* View 8: Expense Management Component */}
        {activeView === 'expenses' && (
          <ExpenseManagement />
        )}

        {/* View 9: Roles & Granular RBAC Permissions */}
        {activeView === 'roles' && (
          <RoleManagement />
        )}

        {/* View 10: Notification Center Component */}
        {activeView === 'notifications' && (
          <NotificationCenter />
        )}

        {/* View 11: Next.js Login Component */}
        {activeView === 'login' && (
          <div className="py-4 my-auto">
            <LoginPage onLoginSuccess={handleLoginSuccess} />
          </div>
        )}

        {/* View 12: Main Operational Dashboard & Live KPIs */}
        {activeView === 'dashboard' && (
          <div className="space-y-6">
            
            {/* Live KPI Widgets: Students Today, Pending Payments, Treasury, Halls, WhatsApp */}
            <DashboardWidgets onNavigateToView={(view: any) => setActiveView(view)} />

            {/* Authenticated User Session Profile (if logged in) */}
            {currentUser ? (
              <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-bold text-xl shadow-lg shadow-emerald-500/20">
                      <UserCheck className="w-8 h-8" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-bold text-white">{currentUser.fullName}</h2>
                        <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono font-bold">
                          {currentUser.roles[0]}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        اسم المستخدم: <code className="text-slate-300 font-mono">{currentUser.username}</code> • معرف الحساب: <code className="text-slate-400 font-mono">{currentUser.userId}</code>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-slate-950 border border-slate-800 px-4 py-2 rounded-xl text-xs">
                      <span className="text-slate-500 block text-[10px]">حالة التوكن (JWT):</span>
                      <span className="text-emerald-400 font-mono font-bold">نشط وموقع بـ HS256</span>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-2 bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 px-4 py-2 rounded-xl text-xs font-bold transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>إنهاء الجلسة</span>
                    </button>
                  </div>
                </div>

                {/* Active Permissions Badges */}
                <div className="mt-6 pt-4 border-t border-slate-800">
                  <span className="text-xs text-slate-400 font-semibold block mb-2">
                    الصلاحيات المفعلة لهذا الدور الوظيفي (Granted RBAC Permissions):
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {currentUser.permissions.map((perm, idx) => (
                      <span
                        key={idx}
                        className="text-xs bg-slate-950 border border-emerald-800/60 text-emerald-300 px-3 py-1 rounded-xl font-mono flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        {perm}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">تسجيل الدخول بصلاحيات مدير أو موظف استقبال</h4>
                    <p className="text-xs text-slate-400">سجل دخولك عبر JWT لتفعيل كافة صلاحيات تحصيل الخزنة ومسح الـ QR.</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveView('login')}
                  className="bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition-all flex items-center gap-1.5 whitespace-nowrap shadow-md shadow-cyan-600/20"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>تسجيل الدخول الآن</span>
                </button>
              </div>
            )}

            {/* Quick Access Operational Modules */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div
                onClick={() => setActiveView('backup')}
                className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 p-5 rounded-2xl space-y-2 cursor-pointer transition-all group"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                  <Cloud className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-white text-sm">الأرشفة السحابية والنسخ</h4>
                <p className="text-xs text-slate-400">
                  نسخ احتياطي أوتوماتيكي مشفر بـ AES-256 ومرفوع للسحابة لضمان سلامة البيانات.
                </p>
                <div className="text-xs text-cyan-400 font-bold pt-2 flex items-center gap-1">
                  <span>فتح إدارة النسخ</span>
                  <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                </div>
              </div>

              <div
                onClick={() => setActiveView('student360')}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 p-5 rounded-2xl space-y-2 cursor-pointer transition-all group"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                  <UserCircle className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-white text-sm">ملف الطالب الشامل 360</h4>
                <p className="text-xs text-slate-400">
                  أرشيف تفاعلي كامل يضم الحضور، الدرجات، السجل المالي، وتقارير الواتساب.
                </p>
                <div className="text-xs text-emerald-400 font-bold pt-2 flex items-center gap-1">
                  <span>فتح الملف</span>
                  <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                </div>
              </div>

              <div
                onClick={() => setActiveView('payroll')}
                className="bg-slate-900 border border-slate-800 hover:border-indigo-500/50 p-5 rounded-2xl space-y-2 cursor-pointer transition-all group"
              >
                <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                  <Clock className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-white text-sm">حضور الموظفين والرواتب</h4>
                <p className="text-xs text-slate-400">
                  بصمة دقيقة، خصم تأخيرات، وصرف رواتب من الخزنة المركزية.
                </p>
                <div className="text-xs text-indigo-400 font-bold pt-2 flex items-center gap-1">
                  <span>فتح مسير الرواتب</span>
                  <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                </div>
              </div>

              <div
                onClick={() => setActiveView('analytics')}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 p-5 rounded-2xl space-y-2 cursor-pointer transition-all group"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-white text-sm">تحليلات الخزنة والتدفقات</h4>
                <p className="text-xs text-slate-400">
                  رسوم بيانية لتدفقات الدخل والخرج وصافي الربح اليومي.
                </p>
                <div className="text-xs text-emerald-400 font-bold pt-2 flex items-center gap-1">
                  <span>فتح الرسوم البيانية</span>
                  <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                </div>
              </div>
            </div>

          </div>
        )}

        {/* View 13: FastAPI Backend Explorer & Sandbox */}
        {activeView === 'backend' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">معمارية سيرفر FastAPI ومحددات الأمان (Backend Specs)</h3>
                  <p className="text-xs text-slate-400">
                    تم كتابة كافة نقاط النهاية، ونماذج Pydantic v2، وميدلوير الـ Rate Limiting والـ JWT
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" />
                    <span>حماية التوكنات وتشفير كلمات المرور:</span>
                  </h4>
                  <p className="text-slate-400 leading-relaxed text-[11px]">
                    يتم تشفير كلمات المرور باستخدام <code className="text-cyan-400 font-mono">Bcrypt (12 Rounds)</code>.
                    جلسات الدخول تستخدم توكنات JWT مشفرة بمفتاح HS256 مع صلاحية 8 ساعات، ويتم تفعيل التحقق من الصلاحيات عبر <code className="text-cyan-400 font-mono">RequirePermission</code>.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <Zap className="w-4 h-4" />
                    <span>معدل الطلبات المتقدم (Sliding Window Rate Limiter):</span>
                  </h4>
                  <p className="text-slate-400 leading-relaxed text-[11px]">
                    نقاط النهاية الحساسة مثل <code className="text-amber-400 font-mono">/api/v1/auth/login</code> محمية بحد أقصى 5 طلبات/دقيقة لمنع هجمات التخمين (Brute-force).
                    نقاط التحصيل المالي محددة بـ 30 طلب/دقيقة لمنع التكرار المالي العرضي.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* View 14: PostgreSQL Triggers */}
        {activeView === 'database' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">جداول وتريجرز PostgreSQL المؤتمتة (ACID Automation)</h3>
                  <p className="text-xs text-slate-400">
                    تم كتابة ملف <code className="text-cyan-400 font-mono">database/schema_and_triggers.sql</code> بدون أي اختصارات
                  </p>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs space-y-3">
                <div className="flex items-center gap-2 text-white font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>دوال وتريجرز الأوتوميشن الذاتية المعتمدة:</span>
                </div>
                <ul className="space-y-2 text-slate-300 text-[11px] list-disc list-inside">
                  <li><strong className="text-cyan-300 font-mono">fn_process_student_payment()</strong>: يحدث رصيد الخزنة لحظياً، ويوزع حصة المدرس والسنتر، ويغير حالة الطالب إلى "CLEARED".</li>
                  <li><strong className="text-cyan-300 font-mono">fn_check_treasury_payout()</strong>: يقفل صف الخزنة (SELECT FOR UPDATE) ويمنع أي صرف يتجاوز الرصيد الفعلي (Zero Deficit).</li>
                  <li><strong className="text-cyan-300 font-mono">fn_attendance_per_session_charge()</strong>: يسجل استحقاق مالي فوري عند مسح QR كود الطالب إذا كان نظام المجموعة بالحصة.</li>
                  <li><strong className="text-cyan-300 font-mono">fn_calc_staff_late_minutes()</strong>: يحسب تأخيرات الموظفين بالدقيقة ويخصمها تلقائياً من مسير الرواتب.</li>
                  <li><strong className="text-amber-300 font-mono">fn_audit_sensitive_changes()</strong> (جديد): تريجر التدقيق والشفافية الذي يسجل آلياً أي تعديل أو حذف أو إضافة حساسة مع حفظ المستخدم، التاريخ، والقيم السابقة والجديدة.</li>
                </ul>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400 text-[11px]">مربوط بجداول: students, treasury_transactions, student_payments, teacher_wallets, staff_attendance</span>
                  <button
                    onClick={() => setActiveView('audit')}
                    className="flex items-center gap-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-3 py-1.5 rounded-xl font-bold transition-all text-xs"
                  >
                    <History className="w-3.5 h-3.5" />
                    <span>فتح شاشة فحص سجل التدقيق (Audit Viewer)</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
