/**
 * Unit Tests for Universal Export & Backup Engine
 * Uses node:test and node:assert/strict
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  escapeCsvCell,
  buildCsvContent,
  createFullSystemBackup,
  validateAndParseBackupFile
} from './export-engine';

test('escapeCsvCell correctly escapes commas, quotes, and newlines', () => {
  assert.equal(escapeCsvCell('Hello'), '"Hello"');
  assert.equal(escapeCsvCell('Hello, World'), '"Hello, World"');
  assert.equal(escapeCsvCell('He said "Hello"'), '"He said ""Hello"""');
  assert.equal(escapeCsvCell(12500), '"12500"');
  assert.equal(escapeCsvCell(null), '""');
});

test('buildCsvContent starts with UTF-8 BOM (\uFEFF) and formats Arabic lines correctly', () => {
  const headers = ['اسم الطالب', 'كود الطالب', 'المبلغ المتأخر'];
  const rows = [
    ['أحمد محمود رضوان', 'ST-2026-0012', 350],
    ['مريم طارق الشريف', 'ST-2026-0045', 60]
  ];

  const csv = buildCsvContent(headers, rows);
  // Must start with UTF-8 BOM byte marker so Excel recognizes Arabic
  assert.ok(csv.startsWith('\uFEFF'));
  assert.ok(csv.includes('"أحمد محمود رضوان"'));
  assert.ok(csv.includes('"ST-2026-0012"'));
  assert.ok(csv.includes('"350"'));
  assert.ok(csv.includes('"مريم طارق الشريف"'));
});

test('createFullSystemBackup computes SHA-256 and structures all system sections', async () => {
  const backup = await createFullSystemBackup({
    centerInfo: {
      name: 'سنتر النخبة التعليمي',
      currency: 'ج.م',
      phone: '01009988776',
      defaultSplitPercent: 75
    }
  });

  assert.equal(backup.version, '2026.1.0');
  assert.equal(backup.centerInfo.name, 'سنتر النخبة التعليمي');
  assert.equal(backup.centerInfo.defaultSplitPercent, 75);
  assert.ok(backup.checksumSha256.length === 64); // SHA-256 is 64 hex characters
  assert.ok(backup.students.length > 0);
  assert.ok(backup.treasuryTransactions.length > 0);
  assert.ok(backup.enabledModules.attendance === true);
});

test('validateAndParseBackupFile validates valid JSON backup and rejects invalid data', async () => {
  const backup = await createFullSystemBackup();
  const validJson = JSON.stringify(backup);

  const validResult = await validateAndParseBackupFile(validJson);
  assert.equal(validResult.isValid, true);
  assert.equal(validResult.payload?.centerInfo.name, backup.centerInfo.name);

  // Invalid JSON string
  const invalidResult = await validateAndParseBackupFile('{ invalid json');
  assert.equal(invalidResult.isValid, false);
  assert.ok(invalidResult.error?.includes('صيغة الملف غير صالحة'));

  // Corrupted structure
  const corruptedResult = await validateAndParseBackupFile('{"foo": "bar"}');
  assert.equal(corruptedResult.isValid, false);
  assert.ok(corruptedResult.error?.includes('لا يحتوي على بنية النسخة الاحتياطية'));
});
